<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../conexao/conexao.php">
    <link rel="stylesheet" href="../formatacao/bootstrap.css">
    <link rel="stylesheet" href="../formatacao/formLogin.css">
    <link rel="stylesheet" href="../formatacao/formulario.css">
    <link rel="stylesheet" href="../formatacao/index.css">
    <script src="../formatacao/jquery-3.4.1.js"></script>

  </head>
  <body>

  </body>
</html>
