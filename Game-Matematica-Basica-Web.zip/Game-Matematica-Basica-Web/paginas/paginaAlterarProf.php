<?php
@SESSION_START();
include "../paginas/chamarformatacao.php";
include "../conexao/conexao.php";
$_SESSION['nick'] = $_POST['nick'];
$_SESSION['senha'] = $_POST['senha'];
$nick = $_POST['nick'];
$senha_professor = $_POST['senha'];
include "../formatacao/header.php";
include "../formatacao/body.php";
$seletor = "SELECT * FROM professor WHERE nickProf = '$nick' AND senha = '$senha_professor'";
$res = mysqli_query($con, $seletor);
$select = mysqli_fetch_assoc($res);

?>

            <form action="../alterar/alterarProf.php" name="form" method="post" class="pl-5 pt-5 pb-5 text-left w-50">
              <label>Nome: </label>
              <input type="text" name="professor" value="<?php echo $select['professor'];?>" required ><br>
              <label>Nick: </label>
              <input type="text" name="nick" value="<?php echo $select['nickProf'];?>" required ><br>
              <label>Senha: </label>
              <input type="text" name="senha" value="<?php echo $select['senha'];?>" required ><br>

              <div class="text-center pr-5">
                <input type="hidden" name='idprofessor' value="<?php echo $select['idprofessor']; $select['professor']; $select['nickProf']; $select['senha']; ?>" class="p-2 mt-1 btn-danger"></input>
                <button type="submit" name="button">Alterar</button>
                <!-- <input type="button" value="Cancelar" class="p-2 mt-1 btn-danger" href="../paginas/perfil.php"></input> -->
              </div>
            </form>
            <br>

            <br>
            <div class="p-4 m-4">

            </div>
<?php include "../formatacao/bottom.php"; ?>
</html>
