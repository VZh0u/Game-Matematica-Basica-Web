<?php
include "chamarformatacao.php";
include "../conexao/conexao.php";
 ?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>

    <title>Tela Inicial</title>

    <script type="text/javascript" src="../formatacao/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="../formatacao/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="../formatacao/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../formatacao/datatable.js"></script>
    <link rel="stylesheet" href="..\formatacao\jquery.dataTables.min.css">
    <link rel="stylesheet" href="..\formatacao\responsive.dataTables.min.css">


  </head>
  <div class="p-1">
  </div>
  <body class="bg-dark">

    <div class="container bg-warning">
      <div class="row">
        <?php include "../menu/bar.php"; ?>
          <div class="col-sm-8 pt-1 pl-5 mt-5 ml-3" align="center">

<?php

  $aluno = mysqli_query($con, "SELECT aluno.aluno, aluno.nick, turma.turma, turma.periodo, escola.escola, professor.professor
    FROM aluno INNER JOIN turma ON aluno.idturma = turma.idturma INNER JOIN escola ON turma.idescola = escola.idescola
    INNER JOIN professor ON turma.idprofessor = professor.idprofessor ORDER BY aluno.aluno");
  $turma = mysqli_query($con, "SELECT * FROM turma");
  $escola = mysqli_query($con, "SELECT * FROM escola");
  $professor = mysqli_query($con, "SELECT * FROM professor");
  // $jogo = mysqli_query($con, "SELECT * FROM jogo ORDER BY pontuacao"); Fazer inner join com a tabela jogo

 ?>


            <table id="teste" class="display responsive nowrap" style="width:100%">
          <thead>
              <tr>
                  <!-- nome, turma, pontuação -->
                  <th>Nome</th>
                  <th>Nick</th>
                  <th>Professor</th>
                  <th>Turma</th>
                  <th>Período</th>
                  <th>Escola</th>
                  <!-- <th>Pontuação</th> -->
              </tr>
          </thead>
          <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($aluno)) {?>
              <!-- Linha -->
              <tr>
                <!-- Colunas -->
              <td><?php echo "".$row['aluno']; ?></td>
              <td><?php echo "".$row['nick']; ?></td>
              <td><?php echo "".$row['professor']; ?></td>
              <td><?php echo "".$row['turma']; ?></td>
              <td><?php echo "".$row['periodo']; ?></td>
              <td><?php echo "".$row['escola']; ?></td>
              <!-- <td>61</td> -->
              </tr>
            <?php } ?>

          </tbody>
      </table>

            <div class="p-2 m-2">

            </div>
        </div>
      </div>
    </div>
  </body>
</html>
