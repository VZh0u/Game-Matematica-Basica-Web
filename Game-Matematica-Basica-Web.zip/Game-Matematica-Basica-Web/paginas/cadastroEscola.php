<?php
include "chamarformatacao.php";
 ?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>

    <title>Tela Cadastro Escola</title>

  </head>
  <body class="bg-dark">
    <div class="p-1 pt-5 mt-5">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <?php include "../menu/bar.php"; ?>
          <div class="col-sm-11 pl-5 ml-4" align="center">
            <div class="p-5 m-1 mt-3">

            </div>
            <div class="container">
            <form action="../verificarDados/verificarEscola.php" method="post" class=" ">
            <!-- action, informa para onde os dados iram -->
            <!-- post esconde os dados privados da url -->
            <label>Escola: </label>
            <input type="text" name="escola" value=""><br>

            <input type="submit" value="Cadastrar" class="p-2 mt-1 btn-danger" id="btn-save"></input>

            </form>
            <br>

            <br>
            <div class="p-5 m-5">

            </div>
        </div>
      </div>
    </div>
  </body>
</html>
