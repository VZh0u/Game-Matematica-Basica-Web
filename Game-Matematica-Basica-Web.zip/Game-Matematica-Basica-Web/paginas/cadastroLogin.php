<?php
include "chamarformatacao.php";
 ?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>

    <title>Tela Cadastro</title>

  </head>
  <body class="bg-dark">
    <style>
      .medio {
                width: 22.8%;
              }
    </style>
    <div class="p-4 m-5">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <?php include "../menu/bar.php"; ?>
          <div class="col-sm-11 pt-5 mt-2" align="center">

            <div class="p-2 m-4">

            </div>
            <a
              href="cadastro.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 ml-5 medio">
              Cadastre-se
            </a>
            <a
              href="cadastroEscola.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 ml-5 medio">
              Cadastrar Escola
            </a>
            <a
              href="login.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 ml-5 medio">
              Login
            </a>
            <br>
            <div class="p-5 m-5">

            </div>
        </div>
      </div>
    </div>
  </body>
</html>
