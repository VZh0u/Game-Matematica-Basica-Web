<?php
include "chamarformatacao.php";
 ?>
 <?php include "../formatacao/header.php"; ?>
     <title>Tela Inicial</title>
     <meta charset="utf-8">
   </head>
   <style>
   .meio {
     width: 18.8%;
     margin-right: 7%;
   }
   </style>
   <?php include "../formatacao/body.php"; ?>
   <p class="meio" style="font-size:150%;color:white; margin-top:-7%;">Tela Inicial</p>
 <div class="p-5 m-5">

 </div>
             <a
               href="cadastro.php"
                 class="btn btn-danger pt-3 pb-3 meio">
               Cadastre-se
             </a>
             <br><br>
             <a
               href="cadastroEscola.php"
                 class="btn btn-danger pt-3 pb-3 meio">
               Cadastrar Escola
             </a>
             <br><br>
             <a
               href="login.php"
                 class="btn btn-danger pt-3 pb-3 meio">
               Login
             </a>
            <br>
            <div class="p-5 m-5">
            </div>
            <div class="p-5 m-5">
            </div>
      </div>
    </div>
  </body>
</html>
