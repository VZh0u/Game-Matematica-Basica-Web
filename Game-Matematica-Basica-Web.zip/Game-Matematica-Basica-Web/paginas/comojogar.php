<?php
include "chamarformatacao.php";


 ?>

<!DOCTYPE html>
<?php include "../formatacao/header.php"; ?>

    <title>Tela Inicial</title>

<?php include "../formatacao/body.php"; ?>

<!-- Conteudo -->

<?php include "../formatacao/bottom.php"; ?>
