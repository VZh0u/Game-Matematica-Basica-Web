<?php
include "chamarformatacao.php";
 ?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>

    <title>Tela Inicial</title>

  </head>
  <body class="bg-dark">
    <div class="p-5 m-3">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <?php include "../menu/bar.php"; ?>
          <div class="col-sm-11 pt-5" align="center">
            <div class="p-2 m-2">

            </div>



            <div class="p-5 m-3">

            </div>
        </div>
      </div>
    </div>
  </body>
</html>
