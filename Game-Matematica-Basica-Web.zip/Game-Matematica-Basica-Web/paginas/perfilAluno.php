<?php
include "chamarformatacao.php";
include "../conexao/conexao.php";

// $nome = $_POST['nome'];
// $cargo = $_POST['cargo'];
// $escola = $_POST['escola'];
// $turma = $_POST['turma'];
// $peri = $_POST['periodo'];
// $nick = $_POST['nick'];
// $senha = $_POST['senha'];

//Conferindo
$select = "SELECT * FROM aluno INNER JOIN turma ON aluno.idturma = turma.idturma INNER JOIN professor ON turma.idprofessor = professor.idprofessor";
$result = mysqli_query($con, $select) or die('Failed to query database. <br>'.mysqli_error($con));
$row = mysqli_fetch_array($result);

$select_aluno="SELECT aluno FROM aluno WHERE $nick = 'nick'";

?>

<html lang="pt-br" dir="ltr">
  <head>

    <title>Perfil Aluno</title>


    <!-- Personalizar alert -->
      <script src="../formatacao/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/xxjapp/xdialog@3/xdialog.min.css"/>
    <script src="https://cdn.jsdelivr.net/gh/xxjapp/xdialog@3/xdialog.min.js"></script> <!-- Import xdialog, para formatar o alert() -->
    <link rel="stylesheet" href="../alert/alerta.css">


    <!-- verificando campos -->
    <script type="text/javascript">
    function validar(){

      var escola = form.escola.value;
      var turma = form.turma.value;
      var periodo = form.periodo.value;

      var esc = document.form.escola.options[document.form.escola.selectedIndex].text;
      var tur = document.form.turma.options[document.form.turma.selectedIndex].text;
      var peri = document.form.periodo.options[document.form.periodo.selectedIndex].text;


      if (escola == "") {
        xdialog.alert('Escola não selecionada!');
      }
      if (turma == "") {
        xdialog.alert('Turma não selecionada!');
      }

      if (periodo == "") {
        xdialog.alert('Período não selecionado!');
      }
    }
        </script>

  </head>
  <body class="bg-dark">
    <div class="p-1">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <?php include "../menu/bar.php"; ?>
          <div class="col-sm-11 pl-5 ml-4 " align="center">
            <div class="p-5 m-2">

            </div>
            <div class="container">
            <form action="../verificarDados/verificar.php" name="form" method="post" class="pl-5 pt-5 pb-5 text-left w-50">
              <?php echo "Logou com sucesso! Bem vindo(a), ".$row['$select_aluno']."!"; ?>
            </form>
            <br>

            <br>
            <div class="p-4 m-4">

            </div>
        </div>
      </div>
    </div>
    <div class="p-3">

    </div>
  </body>
</html>
