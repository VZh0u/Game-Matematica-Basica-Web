<?php
include "../paginas/chamarformatacao.php";
include "../conexao/conexao.php";
include "../verificarDados/dadosRanking.php"; ?>
