<html lang="pt-br">
<meta charset="UTF-8">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="container">

<div class="modal fade" id="modal-mensagem" tabindex="-1" role="dialog" aria-labelledy="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
      <div class="modal-header">
        <h4 class="modal-title">Título da mensagem</h4>
      </div>
      <div class="modal-body">
        <p>Conteúdo da mensagem</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>
<!-- <button class="btn btn-primary" data-toggle="modal" data-target="#modal-mensagem">Exibir mensagem</button> -->
</div>
