<?php
include "../paginas/chamarformatacao.php";
include "../conexao/conexao.php";
?>

<html lang="pt-br" dir="ltr">
<meta charset="utf-8">
  <head>

    <script src="../formatacao/jquery-3.4.1.js"></script>
    <!-- Personalizar alert -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/xxjapp/xdialog@3/xdialog.min.css"/> -->
    <script src="https://cdn.jsdelivr.net/gh/xxjapp/xdialog@3/xdialog.min.js"></script> <!-- Import xdialog, para formatar o alert() -->
    <!-- <link rel="stylesheet" href="../alert/alerta.css"> -->
