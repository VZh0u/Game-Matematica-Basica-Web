<?php
unset($nome);
unset($nick);
@session_destroy();

header("location: ../paginas/index.php");
 ?>
