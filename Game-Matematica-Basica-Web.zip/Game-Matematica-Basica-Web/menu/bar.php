<?php
include "../paginas/chamarformatacao.php";
@session_start();
 ?>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<nav style="background:#4d88ff" class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">

  <a class="" href="index.php">
    <!-- icone -->
    <img src="https://upload.wikimedia.org/wikipedia/commons/a/ab/Logo_TV_2015.png" width="60" height="40" alt="" content="0;url=../paginas/index.php">
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">    <span class="navbar-toggler-icon"></span>
  </button>
<style media="screen">
table, tr, td {
border: 0px;
}
</style>
  <div>
    <table>
      <tr style="background:#4d88ff">
        <td>
          <a class="nav-link" href="../paginas/index.php" onmouseover="style='color:black'; background:#6699ff; border-style:" onmouseout="style='color:black'" style="color:black;">
                <img src="https://image.flaticon.com/icons/svg/263/263115.svg" width="10%" title="Página Inicial">Início<span class="sr-only"></span></a>
              </li>
        </td>
        <td>
          <a class="nav-link" href="../paginas/comojogar.php" style="color:black;margin-left:-40%;">
            <img src="https://img.icons8.com/ios/100/000000/question-mark.png" width="8%" title="Página Inicial">Como Jogar?<span class="sr-only"></span></a>
        </td>
        <td>

          <a class="nav-item dropdown"><a class="dropdown-toggle" data-toggle="dropdown" style="color:black; margin-left:-65%;"> <img src="https://img.icons8.com/dotty/80/000000/student-registration.png" width="14%" title="Página Inicial">Cadastrar</a>
            <ul class="dropdown-menu" style="margin-left:50%; margin-top:-2.5%;">
              <li><a href="../paginas/cadastro.php">Aluno / Professor</a></li>
              <li><a href="../paginas/cadastroEscola.php">Escola</a></li>
              <!-- <li><a href="../paginas/cadastro.php">Professor</a></li> -->
            </ul>
          </a>
        </td>

        <td>
            <a class="nav-link" href="../paginas/login.php" style="color:black; margin-left:-70%;">
              <img src="https://img.icons8.com/ios/100/000000/enter-2.png" width="8%" title="Página Inicial">Login<span class="sr-only"></span></a>
        </td>
      </tr>
  
            <?php if (isset($NICK)) { ?>

            <?php } else { ?>
            <?php } ?>

            <!-- <a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a> -->
          </div>
          <div class="pl-5 ml-5">
            <div class="pl-5 ml-5">
              <div class="pl-5 ml-5">
                <div class="pl-5 ml-5">
                  <div class="pl-5 ml-5">
                    <div class="pl-5 ml-5">
                      <div class="pl-5 ml-5">
                        <div class="pl-5 ml-5">
                          <div class="pl-5 ml-5">
                            <div class="pl-5 ml-5">
                              <div class="pl-4 ml-5">
                                <div class="pl-2">
                                  <div class="pl-1">

                                    <?php if (isset($NICK)) { ?>
                                      <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
                                        <ul class="navbar-nav">
                                          <ul class="nav navbar-nav">
                                            <li class="nav-item dropdown"><a class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['nick'] ?></a>
                                              <ul class="dropdown-menu">
                                                <li><a href="../verificarDados/deslogar.php" class="dropdown-item">Sair</a></li>
                                              </ul>
                                            </li>
                                          </ul>
                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php } ?>
          </div>

    </table>
    </ul>
    </ul>
  </div>
</nav>
