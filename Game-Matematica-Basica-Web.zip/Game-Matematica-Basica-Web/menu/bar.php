<?php
include "../paginas/chamarformatacao.php";

function mostrar(){
  ?><div class="dropdown-menu show" aria-labelledby="navbarDropdown">
  <a class="dropdown-item" href="#">Action</a>
  <a class="dropdown-item" href="#">Another action</a>
  <div class="dropdown-divider"></div>
  <a class="dropdown-item" href="#">Something else here</a>
  </div>
  <?php
}

 ?>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-warning">
  <div class="container-fluid">

  <a class="" href="index.php">
    <img src="https://upload.wikimedia.org/wikipedia/commons/a/ab/Logo_TV_2015.png" width="60" height="40" alt="" content="0;url=../paginas/index.php">
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#conteudoNavbarSuportado" aria-controls="conteudoNavbarSuportado" aria-expanded="false" aria-label="Alterna navegação">    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="conteudoNavbarSuportado">
    <ul class="navbar-nav mr-auto">
      <ul class="nav navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="../paginas/index.php">Início<span class="sr-only"></span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="../paginas/comojogar.php">Como Jogar?<span class="sr-only"></span></a>
        </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown">Cadastrar <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../paginas/cadastroAluno.php">Aluno</a></li>
          <li><a href="../paginas/cadastroEscola.php">Escola</a></li>
          <li><a href="../paginas/cadastroProfessor.php">Professor</a></li>
        </ul>
      </li>
    </ul>

      <!-- <li class="nav-item active">
        <a class="nav-link" href="../paginas/jogar.php">Cadastrar<span onclick="return mostrar()" class="sr-only"></span></a>
      </li> -->
      <li class="nav-item active">
        <a class="nav-link" href="../paginas/login.php">Login<span class="sr-only"></span></a>
      </li>

    </ul>
  </div>
</nav>
