<meta charset="utf-8">
<?php
include "../conexao/conexao.php";

$nome = $_POST['professor'];
$nick = $_POST['nick'];
$senha = $_POST['senha'];
$id = $_POST['idprofessor'];

// $anick = $row['nick'];
// $asenha= $row2['senha'];

$update_professor = "UPDATE professor set professor='$nome', nickProf='$nick', senha= '$senha' WHERE idprofessor = '$id'";
// $update_prof = "UPDATE professor set nick='$nick', senha= '$senha' WHERE idprofessor = '$idprof'";
$result = mysqli_query($con, $update_professor) or die('Failed to query database. <br>'.mysqli_error($con));
// $result2 = mysqli_query($con, $update_prof) or die('Failed to query database. <br>'.mysqli_error($con));
// $row = mysqli_fetch_array($result);
include "../paginas/perfilProfessor.php";
 ?>
