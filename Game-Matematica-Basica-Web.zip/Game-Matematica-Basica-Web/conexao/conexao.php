<?php

$servidor = "localhost";
$usuario = "root";
$senha = "root";
$db = "jogomatematica";

$con = mysqli_connect($servidor, $usuario, $senha, $db);

 ?>
