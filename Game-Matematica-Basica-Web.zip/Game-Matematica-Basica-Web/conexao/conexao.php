<?php

$servidor = "localhost";
$usuario = "root";
$senhaB = "mysql";
$db = "jogomatematica";

$con = mysqli_connect($servidor, $usuario, $senhaB, $db);

 ?>
