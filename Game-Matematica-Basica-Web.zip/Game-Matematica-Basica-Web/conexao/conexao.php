<?php

$servidor = "localhost";
$usuario = "root";
$senhaB = "";
$db = "jogomatematica";

$con = mysqli_connect($servidor, $usuario, $senhaB, $db);

 ?>
