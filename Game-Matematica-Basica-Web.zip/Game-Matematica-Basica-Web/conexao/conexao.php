<?php

$servidor = "localhost";
$usuario = "root";
$senhaB = "root";
$db = "jogomatematica";

$con = mysqli_connect($servidor, $usuario, $senhaB, $db);

 ?>
