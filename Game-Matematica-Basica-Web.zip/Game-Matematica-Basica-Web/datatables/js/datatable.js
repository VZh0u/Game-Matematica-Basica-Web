$(document).ready(function() {
    $('#teste').DataTable();
} );
